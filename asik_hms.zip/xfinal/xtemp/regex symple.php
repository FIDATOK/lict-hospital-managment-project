ldjjjjj8ok

^(?=.*\d)(?=.*[a-zA-Z]).{10}$
^.*(?=.{6,})(?=.*[a-zA-Z])[a-zA-Z0-9]+$
gggjgjg565656A
gfgfgfggggfgfgf
^(?=.*\d+)(?=.*[a-zA-Z])[0-9a-zA-Z!@#$%]{6,10}$
hhhhhA55dd
