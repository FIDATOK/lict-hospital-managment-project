<?php
if(isset($_POST['submit']) == true & & empty($_POST['mail'])==false){
  $email=$_POST['mail'];
  if (FILTER_VAR($email,FILTER_VALIDATE MAIL)==TRUE){
    //YAY
  }else {
      //eio_nready


  }
}
 ?>
 <form class="" action="" method="post">
   <input type="text" name="mail" value="">
   <input type="submit" name="submit" value="">
 </form>
