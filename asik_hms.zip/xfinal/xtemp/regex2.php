<?php
if(isset($_POST['submit'])) {

  $string=$_POST['mail'];
//$string = "/suman.fgfhjfh@iiht.com/" ;
$regex_rule1="/([a-z0-9_.])+\@+([a-z])+\.+([a-z]{2,6})+\.+([a-z]{2,6})/";
$regex_rule2="/([a-z0-9_.])+(\@)+([a-z])+(\.)+([a-z])/";
if (preg_match($regex_rule1,$string) || preg_match($regex_rule2,$string)){
  echo "email valied";

}else{
  echo "invalied mail";
}
}
require("regex8.html");
 ?>
