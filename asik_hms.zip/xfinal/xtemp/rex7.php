<?php
require('regex8.html');
$user='root';
$password='';
$ip='localhost';
$dbname='xfinal';
if(isset($_POST['submit'])) {

  $string=$_POST['mail'];
  $phn=$_POST['phn'];
//$string = "/suman.fgfhjfh@iiht.com/" ;
$regex_rule1="/([a-z0-9_.])+\@+([a-z])+\.+([a-z]{2,6})+\.+([a-z]{2,6})/";
$regex_rule2="/([a-z0-9_.])+(\@)+([a-z])+(\.)+([a-z])/";
$regex_phn="/01[^1-4]\d{8}/";
if (preg_match($regex_rule1,$string) || preg_match($regex_rule2,$string) && preg_match($regex_phn,$phn)) {
  echo "email valied";
  $connection_write = mysqli_connect($ip, $user, $password, $dbname);
$query="INSERT INTO mail(`email`,`phn`) VALUES('$string','$phn')";
mysqli_query($connection_write,$query);
}else{
  echo "invalied mail";
}
}

 ?>
