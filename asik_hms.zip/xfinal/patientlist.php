<?php
require("patientlist.html");
//code Giver= SUMAN GANGOPADHYAY
//modified by asikur rahman

//READ DATA FROM DATABASE USING PHP
$user = 'root';
$password = '';
$ip = 'localhost';
$dbname = 'xfinal';
$connection_read = mysqli_connect($ip, $user, $password, $dbname);
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM patient WHERE `visible` = 1";
    $result = mysqli_query($connection_read, $query);
    if($result){
      echo "<table id='tbl'>
    <tr>
      <th>Sl. No.</th>
      <th>Unique ID</th>
      <th>Name</th>
      <th>Login ID</th>
      <th>Password</th>
      <th>Update Record</th>
      <th>Delete Record</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['sl_no'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".$row['sl_no']."</td>";
      echo "<td>".ucwords($row['fname'])."</td>";
      echo "<td>".$row['phn']."</td>";
      echo "<td>".$row['occu']."</td>";
      echo "<td>"."<a href = 'update.php?id=$id' id='update'>EDIT</a>"."</td>";
      echo "<td>"."<a href = 'delete.php?id=$id' id='delete'>DEL</a>"."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection_read);
?>
