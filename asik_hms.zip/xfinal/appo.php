<?php

//READ DATA FROM DATABASE USING PHP
$user = 'root';
$password = '';
$ip = 'localhost';
$dbname = 'xfinal';
$connection_read = mysqli_connect($ip, $user, $password, $dbname);
  if (!mysqli_connect_errno()) {
    $query = " SELECT doctor.name,doctor.sex,login_system.name,doctor.dsepc FROM doctor RIGHT JOIN login_system ON login_system.id=doctor.id;" ;
  //  $query = "SELECT * FROM patient " ;
    $result = mysqli_query($connection_read, $query);
    if($result) {
    //  $header=["header"];
      //echo "$header";
      echo "<table >
    <tr>
      <th>Sl. No.</th>

      <th>Doctor Name</th>
      <th>patient </th>
      <th>Speciallist</th>

      <th>Showing date</th>
      <th>Update Record</th>
      <th>Delete Record</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
        $id = $row['dsepc'];
      //$id = $row['dno'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".$row['name']."</td>";
      echo "<td>".ucwords($row['name'])."</td>";
      echo "<td>".$row['sex']."</td>";

      //echo "<td>".$row['dshow']."</td>";
      echo "<td>"."<a href = 'update.php?id=$id' id='update'>EDIT</a>"."</td>";
      echo "<td>"."<a href = 'delete.php?id=$id' id='delete'>DEL</a>"."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection_read);






require("appo.html");
 ?>
