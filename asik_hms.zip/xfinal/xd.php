<?php

$max    = 'fname';
$string = 'lname';

// Check only letters; the regex searches for anything that isn't a plain letter
if (preg_match('/[^a-zA-Z]/', $string)){
    echo 'only letters are allowed';
}

// Check a value is provided
$len = strlen($string);
if ($len == 0) {
    echo 'you must provide a value';
}

// Check the string is long to long
if ($len > $max) {
   echo 'the value cannot be longer than ' . $max;
}
?>
<?php
require('index.html');
 ?>
